'Skeleton Program code for the AQA A Level Paper 1 Summer 2019 examination
'this code should be used in conjunction with the Preliminary Material
'written by the AQA Programmer Team
'developed in the Visual Studio Community Edition programming environment

Imports System.IO
Module Module1
    Const Inventory As Integer = 1001
    Const MinimumIDForItem As Integer = 2001
    Const IDDifferenceForObjectInTwoLocations As Integer = 10000

    Structure Place
        Dim Description As String
        Dim ID, North, East, South, West, Up, Down As Integer
    End Structure

    Structure Character
        Dim Name, Description As String
        Dim ID, CurrentLocation As Integer
    End Structure

    Structure Item
        Dim ID, Location As Integer
        Dim Description, Status, Name, Commands, Results As String
    End Structure

    Function GetInstruction() As String
        Dim Instruction As String
        Console.Write(Environment.NewLine & "> ")
        Instruction = Console.ReadLine.ToLower
        Return Instruction
    End Function

    Function ExtractCommand(ByRef Instruction As String) As String
        Dim Command As String = ""
        If Not Instruction.Contains(" ") Then
            Return Instruction
        End If
        While Instruction.Length > 0 And Instruction(0) <> " "
            Command &= Instruction(0)
            Instruction = Instruction.Remove(0, 1)
        End While
        While Instruction.Length > 0 And Instruction(0) = " "
            Instruction = Instruction.Remove(0, 1)
        End While
        Return Command
    End Function

    Function Go(ByRef You As Character, ByVal Direction As String, ByVal CurrentPlace As Place) As Boolean
        Dim Moved As Boolean = True
        Select Case Direction
            Case "north"
                If CurrentPlace.North = 0 Then
                    Moved = False
                Else
                    You.CurrentLocation = CurrentPlace.North
                End If
            Case "east"
                If CurrentPlace.East = 0 Then
                    Moved = False
                Else
                    You.CurrentLocation = CurrentPlace.East
                End If
            Case "south"
                If CurrentPlace.South = 0 Then
                    Moved = False
                Else
                    You.CurrentLocation = CurrentPlace.South
                End If
            Case "west"
                If CurrentPlace.West = 0 Then
                    Moved = False
                Else
                    You.CurrentLocation = CurrentPlace.West
                End If
            Case "up"
                If CurrentPlace.Up = 0 Then
                    Moved = False
                Else
                    You.CurrentLocation = CurrentPlace.Up
                End If
            Case "down"
                If CurrentPlace.Down = 0 Then
                    Moved = False
                Else
                    You.CurrentLocation = CurrentPlace.Down
                End If
            Case Else
                Moved = False
        End Select
        If Not Moved Then
            Console.WriteLine("You are not able to go in that direction.")
        End If
        Return Moved
    End Function

    Sub DisplayDoorStatus(ByVal Status As String)
        If Status = "open" Then
            Console.WriteLine("The door is open.")
        Else
            Console.WriteLine("The door is closed.")
        End If
    End Sub

    Sub DisplayContentsOfContainerItem(ByVal Items As ArrayList, ByVal ContainerID As Integer)
        Console.Write("It contains: ")
        Dim ContainsItem As Boolean = False
        For Each Thing In Items
            If Thing.location = ContainerID Then
                If ContainsItem Then
                    Console.Write(", ")
                End If
                ContainsItem = True
                Console.Write(Thing.name)
            End If
        Next
        If ContainsItem Then
            Console.WriteLine(".")
        Else
            Console.WriteLine("nothing.")
        End If
    End Sub

    Sub Examine(ByVal Items As ArrayList, ByVal Characters As ArrayList, ByVal ItemToExamine As String, ByVal CurrentLocation As Integer)
        Dim Count As Integer = 0
        If ItemToExamine = "inventory" Then
            DisplayInventory(Items)
        Else
            Dim IndexOfItem As Integer = GetIndexOfItem(ItemToExamine, -1, Items)
            If IndexOfItem <> -1 Then
                If Items(IndexOfItem).Name = ItemToExamine And (Items(IndexOfItem).Location = Inventory Or Items(IndexOfItem).Location = CurrentLocation) Then
                    Console.WriteLine(Items(IndexOfItem).Description)
                    If Items(IndexOfItem).Name.Contains("door") Then
                        DisplayDoorStatus(Items(IndexOfItem).Status)
                    End If
                    If Items(IndexOfItem).Status.Contains("container") Then
                        DisplayContentsOfContainerItem(Items, Items(IndexOfItem).ID)
                    End If
                    Exit Sub
                End If
            End If
            While Count < Characters.Count
                If Characters(Count).Name = ItemToExamine And Characters(Count).CurrentLocation = CurrentLocation Then
                    Console.WriteLine(Characters(Count).Description)
                    Exit Sub
                End If
                Count += 1
            End While
            Console.WriteLine("You cannot find " & ItemToExamine & " to look at.")
        End If
    End Sub

    Function GetPositionOfCommand(ByVal CommandList As String, ByVal Command As String) As Integer
        Dim Position As Integer = 0
        Dim Count As Integer = 0
        While Count <= CommandList.Length - Command.Length
            If CommandList.Substring(Count, Command.Length) = Command Then
                Return Position
            ElseIf CommandList(Count) = "," Then
                Position += 1
            End If
            Count += 1
        End While
        Return Position
    End Function

    Function GetResultForCommand(ByVal Results As String, ByVal Position As Integer) As String
        Dim Count As Integer = 0
        Dim CurrentPosition As Integer = 0
        Dim ResultForCommand As String = ""
        While CurrentPosition < Position And Count < Results.Length
            If Results(Count) = ";" Then
                CurrentPosition += 1
            End If
            Count += 1
        End While
        While Count < Results.Length
            If Results(Count) = ";" Then
                Exit While
            End If
            ResultForCommand &= Results(Count)
            Count += 1
        End While
        Return ResultForCommand
    End Function

    Sub Say(ByVal Speech As String)
        Console.WriteLine()
        Console.WriteLine(Speech)
        Console.WriteLine()
    End Sub

    Sub ExtractResultForCommand(ByRef SubCommand As String, ByRef SubCommandParameter As String, ByVal ResultForCommand As String)
        Dim Count As Integer = 0
        While Count < ResultForCommand.Length AndAlso ResultForCommand(Count) <> ","
            SubCommand &= ResultForCommand(Count)
            Count += 1
        End While
        Count += 1
        While Count < ResultForCommand.Length
            If ResultForCommand(Count) <> "," And ResultForCommand(Count) <> ";" Then
                SubCommandParameter &= ResultForCommand(Count)
            Else
                Exit Sub
            End If
            Count += 1
        End While
    End Sub

    Sub ChangeLocationReference(ByVal Direction As String, ByVal NewLocationReference As Integer, ByVal Places As ArrayList, ByVal IndexOfCurrentLocation As Integer, ByVal Opposite As Boolean)
        Dim ThisPlace As New Place
        ThisPlace = Places(IndexOfCurrentLocation)
        If Direction = "north" And Not Opposite Or Direction = "south" And Opposite Then
            ThisPlace.North = NewLocationReference
        ElseIf Direction = "east" And Not Opposite Or Direction = "west" And Opposite Then
            ThisPlace.East = NewLocationReference
        ElseIf Direction = "south" And Not Opposite Or Direction = "north" And Opposite Then
            ThisPlace.South = NewLocationReference
        ElseIf Direction = "west" And Not Opposite Or Direction = "east" And Opposite Then
            ThisPlace.West = NewLocationReference
        ElseIf Direction = "up" And Not Opposite Or Direction = "down" And Opposite Then
            ThisPlace.Up = NewLocationReference
        ElseIf Direction = "down" And Not Opposite Or Direction = "up" And Opposite Then
            ThisPlace.Down = NewLocationReference
        End If
        Places(IndexOfCurrentLocation) = ThisPlace
    End Sub

    Function OpenClose(ByVal Open As Boolean, ByVal Items As ArrayList, ByVal Places As ArrayList, ByVal ItemToOpenClose As String, ByVal CurrentLocation As Integer) As Integer
        Dim Command, ResultForCommand As String
        Dim Count As Integer = 0
        Dim Position, Count2 As Integer
        Dim Direction As String = ""
        Dim DirectionChange As String = ""
        Dim ActionWorked As Boolean = False
        If Open Then
            Command = "open"
        Else
            Command = "close"
        End If
        While Count < Items.Count And Not ActionWorked
            If Items(Count).Name = ItemToOpenClose Then
                If Items(Count).Location = CurrentLocation Then
                    If Items(Count).Commands.length >= 4 Then
                        If Items(Count).Commands.Contains(Command) Then
                            If Items(Count).Status = Command Then
                                Return -2
                            ElseIf Items(Count).Status = "locked" Then
                                Return -3
                            End If
                            Position = GetPositionOfCommand(Items(Count).Commands, Command)
                            ResultForCommand = GetResultForCommand(Items(Count).Results, Position)
                            ExtractResultForCommand(Direction, DirectionChange, ResultForCommand)
                            ChangeStatusOfItem(Items, Count, Command)
                            Count2 = 0
                            ActionWorked = True
                            While Count2 < Places.Count
                                If Places(Count2).ID = CInt(CurrentLocation) Then
                                    ChangeLocationReference(Direction, CInt(DirectionChange), Places, Count2, False)
                                ElseIf Places(Count2).ID = CInt(DirectionChange) Then
                                    ChangeLocationReference(Direction, CurrentLocation, Places, Count2, True)
                                End If
                                Count2 += 1
                            End While
                            Dim IndexOfOtherSideOfDoor As Integer
                            If Items(Count).ID > IDDifferenceForObjectInTwoLocations Then
                                IndexOfOtherSideOfDoor = GetIndexOfItem("", Items(Count).ID - IDDifferenceForObjectInTwoLocations, Items)
                            Else
                                IndexOfOtherSideOfDoor = GetIndexOfItem("", Items(Count).ID + IDDifferenceForObjectInTwoLocations, Items)
                            End If
                            ChangeStatusOfItem(Items, IndexOfOtherSideOfDoor, Command)
                            Count = Items.Count + 1
                        End If
                    End If
                End If
            End If
            Count += 1
        End While
        If Not ActionWorked Then
            Return -1
        End If
        Return CInt(DirectionChange)
    End Function

    Function GetIndexOfItem(ByVal ItemNameToGet As String, ByVal ItemIDToGet As Integer, Items As ArrayList) As Integer
        Dim Count As Integer = 0
        Dim StopLoop As Boolean = False
        While Not StopLoop And Count < Items.Count
            If (ItemIDToGet = -1 And Items(Count).Name = ItemNameToGet) Or Items(Count).ID = ItemIDToGet Then
                StopLoop = True
            Else
                Count += 1
            End If
        End While
        If Not StopLoop Then
            Return -1
        Else
            Return Count
        End If
    End Function

    Sub ChangeLocationOfItem(ByVal Items As ArrayList, ByVal IndexOfItem As Integer, ByVal NewLocation As Integer)
        Dim ThisItem As Item = Items(IndexOfItem)
        ThisItem.Location = NewLocation
        Items(IndexOfItem) = ThisItem
    End Sub

    Sub ChangeStatusOfItem(ByVal Items As ArrayList, ByVal IndexOfItem As Integer, ByVal NewStatus As String)
        Dim ThisItem As Item = Items(IndexOfItem)
        ThisItem.Status = NewStatus
        Items(IndexOfItem) = ThisItem
    End Sub

    Function GetRandomNumber(ByVal LowerLimitValue As Integer, ByVal UpperLimitValue As Integer) As Integer
        Return Int(Rnd() * (UpperLimitValue - LowerLimitValue + 1)) + LowerLimitValue
    End Function

    Function RollDie(ByVal Lower As String, ByVal Upper As String) As Integer
        Dim LowerLimitValue As Integer = 0
        If IsNumeric(Lower) Then
            LowerLimitValue = CInt(Lower)
        Else
            While LowerLimitValue < 1 Or LowerLimitValue > 6
                Console.Write("Enter minimum: ")
                LowerLimitValue = Console.ReadLine
            End While
        End If
        Dim UpperLimitValue As Integer = 0
        If IsNumeric(Upper) Then
            UpperLimitValue = CInt(Upper)
        Else
            While UpperLimitValue < LowerLimitValue Or UpperLimitValue > 6
                Console.Write("Enter maximum: ")
                UpperLimitValue = Console.ReadLine
            End While
        End If
        Return GetRandomNumber(LowerLimitValue, UpperLimitValue)
    End Function

    Sub ChangeStatusOfDoor(ByVal Items As ArrayList, ByVal CurrentLocation As Integer, ByVal IndexOfItemToLockUnlock As Integer, ByVal IndexOfOtherSideItemToLockUnlock As Integer)
        If CurrentLocation = Items(IndexOfItemToLockUnlock).Location Or CurrentLocation = Items(IndexOfOtherSideItemToLockUnlock).location Then
            If Items(IndexOfItemToLockUnlock).Status = "locked" Then
                ChangeStatusOfItem(Items, IndexOfItemToLockUnlock, "close")
                ChangeStatusOfItem(Items, IndexOfOtherSideItemToLockUnlock, "close")
                Say(Items(IndexOfItemToLockUnlock).Name & " now unlocked.")
            ElseIf Items(IndexOfItemToLockUnlock).Status = "close" Then
                ChangeStatusOfItem(Items, IndexOfItemToLockUnlock, "locked")
                ChangeStatusOfItem(Items, IndexOfOtherSideItemToLockUnlock, "locked")
                Say(Items(IndexOfItemToLockUnlock).Name & " now locked.")
            Else
                Say(Items(IndexOfItemToLockUnlock).Name & " is open so can't be locked.")
            End If
        Else
            Say("Can't use that key in this location.")
        End If
    End Sub

    Sub UseItem(ByVal Items As ArrayList, ByVal ItemToUse As String, ByVal CurrentLocation As Integer, ByRef StopGame As Boolean, ByVal Places As ArrayList)
        Dim Position, IndexOfItem As Integer
        Dim ResultForCommand As String
        Dim SubCommand As String = ""
        Dim SubCommandParameter As String = ""
        IndexOfItem = GetIndexOfItem(ItemToUse, -1, Items)
        If IndexOfItem <> -1 Then
            If Items(IndexOfItem).Location = Inventory Or (Items(IndexOfItem).Location = CurrentLocation And Items(IndexOfItem).Status.Contains("usable")) Then
                Position = GetPositionOfCommand(Items(IndexOfItem).Commands, "use")
                ResultForCommand = GetResultForCommand(Items(IndexOfItem).Results, Position)
                ExtractResultForCommand(SubCommand, SubCommandParameter, ResultForCommand)
                If SubCommand = "say" Then
                    Say(SubCommandParameter)
                ElseIf SubCommand = "lockunlock" Then
                    Dim IndexOfItemToLockUnlock, IndexOfOtherSideItemToLockUnlock As Integer
                    IndexOfItemToLockUnlock = GetIndexOfItem("", CInt(SubCommandParameter), Items)
                    IndexOfOtherSideItemToLockUnlock = GetIndexOfItem("", CInt(SubCommandParameter) + IDDifferenceForObjectInTwoLocations, Items)
                    ChangeStatusOfDoor(Items, CurrentLocation, IndexOfItemToLockUnlock, IndexOfOtherSideItemToLockUnlock)
                ElseIf SubCommand = "roll" Then
                    Say("You have rolled a " & RollDie(ResultForCommand(5), ResultForCommand(7)))
                End If
                Exit Sub
            End If
        End If
        Console.WriteLine("You can't use that!")
    End Sub

    Sub ReadItem(ByVal Items As ArrayList, ByVal ItemToRead As String, ByVal CurrentLocation As Integer)
        Dim SubCommand As String = ""
        Dim SubCommandParameter As String = ""
        Dim IndexOfItem, Position As Integer
        Dim ResultForCommand As String
        IndexOfItem = GetIndexOfItem(ItemToRead, -1, Items)
        If IndexOfItem = -1 Then
            Console.WriteLine("You can't find " & ItemToRead & ".")
        ElseIf Not Items(IndexOfItem).Commands.contains("read") Then
            Console.WriteLine("You can't read " & ItemToRead & ".")
        ElseIf Items(IndexOfItem).Location <> CurrentLocation And Items(IndexOfItem).Location <> Inventory Then
            Console.WriteLine("You can't find " & ItemToRead & ".")
        Else
            Position = GetPositionOfCommand(Items(IndexOfItem).Commands, "read")
            ResultForCommand = GetResultForCommand(Items(IndexOfItem).Results, Position)
            ExtractResultForCommand(SubCommand, SubCommandParameter, ResultForCommand)
            If SubCommand = "say" Then
                Say(SubCommandParameter)
            End If
        End If
    End Sub

    Sub GetItem(ByVal Items As ArrayList, ByVal ItemToGet As String, ByVal CurrentLocation As Integer, ByRef StopGame As Boolean)
        Dim ResultForCommand As String
        Dim SubCommand As String = ""
        Dim SubCommandParameter As String = ""
        Dim IndexOfItem, Position As Integer
        Dim CanGet As Boolean = False
        IndexOfItem = GetIndexOfItem(ItemToGet, -1, Items)
        If IndexOfItem = -1 Then
            Console.WriteLine("You can't find " & ItemToGet & ".")
        ElseIf Items(IndexOfItem).Location = Inventory Then
            Console.WriteLine("You have already got that!")
        ElseIf Not Items(IndexOfItem).Commands.contains("get") Then
            Console.WriteLine("You can't get " & ItemToGet & ".")
        ElseIf Items(IndexOfItem).Location >= MinimumIDForItem AndAlso Items(GetIndexOfItem("", Items(IndexOfItem).Location, Items)).Location <> CurrentLocation Then
            Console.WriteLine("You can't find " & ItemToGet & ".")
        ElseIf Items(IndexOfItem).Location < MinimumIDForItem And Items(IndexOfItem).Location <> CurrentLocation Then
            Console.WriteLine("You can't find " & ItemToGet & ".")
        Else
            CanGet = True
        End If
        If CanGet Then
            Position = GetPositionOfCommand(Items(IndexOfItem).Commands, "get")
            ResultForCommand = GetResultForCommand(Items(IndexOfItem).Results, Position)
            ExtractResultForCommand(SubCommand, SubCommandParameter, ResultForCommand)
            If SubCommand = "say" Then
                Say(SubCommandParameter)
            ElseIf SubCommand = "win" Then
                Say("You have won the game")
                StopGame = True
                Exit Sub
            End If
            If Items(IndexOfItem).Status.contains("gettable") Then
                ChangeLocationOfItem(Items, IndexOfItem, Inventory)
                Console.WriteLine("You have got that now.")
            End If
        End If
    End Sub

    Function CheckIfDiceGamePossible(ByVal Items As ArrayList, ByVal Characters As ArrayList, ByRef IndexOfPlayerDie As Integer, ByRef IndexOfOtherCharacter As Integer, ByRef IndexOfOtherCharacterDie As Integer, ByVal OtherCharacterName As String) As Boolean
        Dim PlayerHasDie As Boolean = False
        Dim PlayersInSameRoom As Boolean = False
        Dim OtherCharacterHasDie As Boolean = False
        For Each Thing In Items
            If Thing.Location = Inventory And Thing.name.contains("die") Then
                PlayerHasDie = True
                IndexOfPlayerDie = GetIndexOfItem("", Thing.ID, Items)
            End If
        Next
        Dim Count As Integer = 1
        While Count < Characters.Count And Not PlayersInSameRoom
            If Characters(0).CurrentLocation = Characters(Count).CurrentLocation And Characters(Count).Name = OtherCharacterName Then
                PlayersInSameRoom = True
                For Each Thing In Items
                    If Thing.Location = Characters(Count).ID And Thing.name.contains("die") Then
                        OtherCharacterHasDie = True
                        IndexOfOtherCharacterDie = GetIndexOfItem("", Thing.ID, Items)
                        IndexOfOtherCharacter = Count
                    End If
                Next
            End If
            Count += 1
        End While
        Return PlayerHasDie And PlayersInSameRoom And OtherCharacterHasDie
    End Function

    Sub TakeItemFromOtherCharacter(ByVal Items As ArrayList, ByVal OtherCharacterID As Integer)
        Dim ListofIndicesOfItemsInInventory As New ArrayList
        Dim ListOfNamesOfItemsInInventory As New ArrayList
        Dim Count As Integer = 0
        While Count < Items.Count
            If Items(Count).Location = OtherCharacterID Then
                ListofIndicesOfItemsInInventory.Add(Count)
                ListOfNamesOfItemsInInventory.Add(Items(Count).Name)
            End If
            Count += 1
        End While
        Count = 1
        Console.Write("Which item do you want to take?  They have: ")
        Console.Write(ListOfNamesOfItemsInInventory(0))
        While Count < ListOfNamesOfItemsInInventory.Count - 1
            Console.Write(", " & ListOfNamesOfItemsInInventory(Count))
            Count += 1
        End While
        Console.WriteLine(".")
        Dim ChosenItem As String = Console.ReadLine
        If ListOfNamesOfItemsInInventory.Contains(ChosenItem) Then
            Console.WriteLine("You have that now.")
            Dim Pos As Integer = ListOfNamesOfItemsInInventory.IndexOf(ChosenItem)
            ChangeLocationOfItem(Items, ListofIndicesOfItemsInInventory(Pos), Inventory)
        Else
            Console.WriteLine("They don't have that item, so you don't take anything this time.")
        End If
    End Sub

    Sub TakeRandomItemFromPlayer(ByVal Items As ArrayList, ByVal OtherCharacterID As Integer)
        Dim ListofIndicesOfItemsInInventory As New ArrayList
        Dim Count As Integer = 0
        While Count < Items.Count
            If Items(Count).Location = Inventory Then
                ListofIndicesOfItemsInInventory.Add(Count)
            End If
            Count += 1
        End While
        Dim rno As Integer = GetRandomNumber(0, ListofIndicesOfItemsInInventory.Count - 1)
        Console.WriteLine("They have taken your " & Items(ListofIndicesOfItemsInInventory(rno)).Name & ".")
        ChangeLocationOfItem(Items, ListofIndicesOfItemsInInventory(rno), OtherCharacterID)
    End Sub

    Sub PlayDiceGame(ByVal Characters As ArrayList, ByVal Items As ArrayList, ByVal OtherCharacterName As String)
        Dim PlayerScore As Integer = 0
        Dim OtherCharacterScore As Integer = 0
        Dim IndexOfPlayerDie, IndexOfOtherCharacterDie, Position, IndexOfOtherCharacter As Integer
        Dim ResultForCommand As String
        Dim DiceGamePossible As Boolean = CheckIfDiceGamePossible(Items, Characters, IndexOfPlayerDie, IndexOfOtherCharacter, IndexOfOtherCharacterDie, OtherCharacterName)
        If Not DiceGamePossible Then
            Console.WriteLine("You can't play a dice game.")
        Else
            Position = GetPositionOfCommand(Items(IndexOfPlayerDie).Commands, "use")
            ResultForCommand = GetResultForCommand(Items(IndexOfPlayerDie).Results, Position)
            PlayerScore = RollDie(ResultForCommand(5), ResultForCommand(7))
            Console.WriteLine("You rolled a " & CStr(PlayerScore) & ".")
            Position = GetPositionOfCommand(Items(IndexOfOtherCharacterDie).Commands, "use")
            ResultForCommand = GetResultForCommand(Items(IndexOfOtherCharacterDie).Results, Position)
            OtherCharacterScore = RollDie(ResultForCommand(5), ResultForCommand(7))
            Console.WriteLine("They rolled a " & CStr(OtherCharacterScore) & ".")
            If PlayerScore > OtherCharacterScore Then
                Console.WriteLine("You win!")
                TakeItemFromOtherCharacter(Items, Characters(IndexOfOtherCharacter).ID)
            ElseIf PlayerScore < OtherCharacterScore Then
                Console.WriteLine("You lose!")
                TakeRandomItemFromPlayer(Items, Characters(IndexOfOtherCharacter).ID)
            Else
                Console.WriteLine("Draw!")
            End If
        End If
    End Sub

    Sub MoveItem(ByVal Items As ArrayList, ByVal ItemToMove As String, ByVal CurrentLocation As Integer)
        Dim Position As Integer
        Dim ResultForCommand As String
        Dim SubCommand As String = ""
        Dim SubCommandParameter As String = ""
        Dim IndexOfItem As Integer = GetIndexOfItem(ItemToMove, -1, Items)
        If IndexOfItem <> -1 Then
            If Items(IndexOfItem).Location = CurrentLocation Then
                If Items(IndexOfItem).Commands.length >= 4 Then
                    If Items(IndexOfItem).Commands.Contains("move") Then
                        Position = GetPositionOfCommand(Items(IndexOfItem).Commands, "move")
                        ResultForCommand = GetResultForCommand(Items(IndexOfItem).Results, Position)
                        ExtractResultForCommand(SubCommand, SubCommandParameter, ResultForCommand)
                        If SubCommand = "say" Then
                            Say(SubCommandParameter)
                        End If
                    Else
                        Console.WriteLine("You can't move " & ItemToMove & ".")
                    End If
                Else
                    Console.WriteLine("You can't move " & ItemToMove & ".")
                End If
                Exit Sub
            End If
        End If
        Console.WriteLine("You can't find " & ItemToMove & ".")
    End Sub

    Sub DisplayInventory(ByVal Items As ArrayList)
        Console.WriteLine()
        Console.WriteLine("You are currently carrying the following items:")
        For Each Thing In Items
            If Thing.Location = Inventory Then
                Console.WriteLine(Thing.Name)
            End If
        Next
        Console.WriteLine()
    End Sub

    Sub DisplayGettableItemsInLocation(ByVal Items As ArrayList, ByVal CurrentLocation As Integer)
        Dim ContainsGettableItems As Boolean = False
        Dim ListOfItems As String = "On the floor there is: "
        For Each Item In Items
            If Item.location = CurrentLocation And Item.Status.contains("gettable") Then
                If ContainsGettableItems Then
                    ListOfItems &= ", "
                End If
                ListOfItems &= Item.Name
                ContainsGettableItems = True
            End If
        Next
        If ContainsGettableItems Then
            Console.WriteLine(ListOfItems & ".")
        End If
    End Sub

    Sub DisplayOpenCloseMessage(ByVal ResultOfOpenClose As Integer, ByVal OpenCommand As Boolean)
        If ResultOfOpenClose >= 0 Then
            If OpenCommand Then
                Say("You have opened it.")
            Else
                Say("You have closed it.")
            End If
        ElseIf ResultOfOpenClose = -3 Then
            Say("You can't do that, it is locked.")
        ElseIf ResultOfOpenClose = -2 Then
            Say("It already is.")
        ElseIf ResultOfOpenClose = -1 Then
            Say("You can't open that.")
        End If
    End Sub

    Sub PlayGame(ByVal Characters As ArrayList, ByVal Items As ArrayList, ByVal Places As ArrayList)
        Dim StopGame As Boolean = False
        Dim Instruction, Command As String
        Dim Moved As Boolean = True
        Dim ResultOfOpenClose As Integer
        Randomize()
        While Not StopGame
            If Moved Then
                Console.WriteLine()
                Console.WriteLine()
                Console.WriteLine(Places(Characters(0).CurrentLocation - 1).Description)
                DisplayGettableItemsInLocation(Items, Characters(0).CurrentLocation)
                Moved = False
            End If
            Instruction = GetInstruction()
            Command = ExtractCommand(Instruction)
            Select Case Command
                Case "get"
                    GetItem(Items, Instruction, Characters(0).CurrentLocation, StopGame)
                Case "use"
                    UseItem(Items, Instruction, Characters(0).CurrentLocation, StopGame, Places)
                Case "go"
                    Moved = Go(Characters(0), Instruction, Places(Characters(0).CurrentLocation - 1))
                Case "read"
                    ReadItem(Items, Instruction, Characters(0).CurrentLocation)
                Case "examine"
                    Examine(Items, Characters, Instruction, Characters(0).CurrentLocation)
                Case "open"
                    ResultOfOpenClose = OpenClose(True, Items, Places, Instruction, Characters(0).CurrentLocation)
                    DisplayOpenCloseMessage(ResultOfOpenClose, True)
                Case "close"
                    ResultOfOpenClose = OpenClose(False, Items, Places, Instruction, Characters(0).CurrentLocation)
                    DisplayOpenCloseMessage(ResultOfOpenClose, False)
                Case "move"
                    MoveItem(Items, Instruction, Characters(0).CurrentLocation)
                Case "say"
                    Say(Instruction)
                Case "playdice"
                    PlayDiceGame(Characters, Items, Instruction)
                Case "quit"
                    Say("You decide to give up, try again another time.")
                    StopGame = True
                Case Else
                    Console.WriteLine("Sorry, you don't know how to " & Command & ".")
            End Select
        End While
        Console.ReadLine()
    End Sub

    Function LoadGame(ByVal Filename As String, ByVal Characters As ArrayList, ByVal Items As ArrayList, ByVal Places As ArrayList)
        Dim NoOfCharacters, NoOfPlaces, Count, NoOfItems As Integer
        Dim TempCharacter As Character
        Dim TempPlace As Place
        Dim TempItem As Item
        Try
            Using Reader As BinaryReader = New BinaryReader(File.Open(Filename, FileMode.Open))
                NoOfCharacters = Reader.ReadInt32
                For Count = 1 To NoOfCharacters
                    TempCharacter.ID = Reader.ReadInt32
                    TempCharacter.Name = Reader.ReadString
                    TempCharacter.Description = Reader.ReadString
                    TempCharacter.CurrentLocation = Reader.ReadInt32
                    Characters.Add(TempCharacter)
                Next
                NoOfPlaces = Reader.ReadInt32
                For Count = 1 To NoOfPlaces
                    TempPlace.ID = Reader.ReadInt32
                    TempPlace.Description = Reader.ReadString
                    TempPlace.North = Reader.ReadInt32
                    TempPlace.East = Reader.ReadInt32
                    TempPlace.South = Reader.ReadInt32
                    TempPlace.West = Reader.ReadInt32
                    TempPlace.Up = Reader.ReadInt32
                    TempPlace.Down = Reader.ReadInt32
                    Places.Add(TempPlace)
                Next
                NoOfItems = Reader.ReadInt32
                For Count = 1 To NoOfItems
                    TempItem.ID = Reader.ReadInt32
                    TempItem.Description = Reader.ReadString
                    TempItem.Status = Reader.ReadString
                    TempItem.Location = Reader.ReadInt32
                    TempItem.Name = Reader.ReadString
                    TempItem.Commands = Reader.ReadString
                    TempItem.Results = Reader.ReadString
                    Items.Add(TempItem)
                Next
            End Using
            Return True
        Catch
            Return False
        End Try
    End Function

    Sub Main()
        Dim Filename As String
        Dim Items, Characters, Places As New ArrayList
        Console.Write("Enter filename> ")
        Filename = Console.ReadLine & ".gme"
        Console.WriteLine()
        If LoadGame(Filename, Characters, Items, Places) Then
            PlayGame(Characters, Items, Places)
        Else
            Console.WriteLine("Unable to load game.")
            Console.ReadLine()
        End If
    End Sub
End Module